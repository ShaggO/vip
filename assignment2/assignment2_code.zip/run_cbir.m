clc, clear all

run('C:\vlfeat-0.9.17\toolbox\vl_setup.m')

n_train = 15;
n_test = 5;
k = 2500;
nth_descriptor = 10;

[train_paths,D_train_idx,D_train,test_paths,D_test_idx,D_test] = ...
    split_data(n_train,n_test);

nth_train_idx = 1:nth_descriptor:size(D_train,1);

% k-means clustering
tic
[words,~] = vl_ikmeans(D_train(nth_train_idx,:)',k);
words = words';
time_kmeans = toc

% get table for each image containing bag of words
tic
table_train = get_table(words,train_paths,D_train,D_train_idx);
table_test = get_table(words,test_paths,D_test,D_test_idx);
time_bow = toc

% compute image distances and matching accuracy
tic
acc_euclidean = image_match(table_train, table_test, 'euclidean')
acc_bhattacharyya = image_match(table_train, table_test, 'bhattacharyya')
acc_kullback = image_match(table_train, table_test, 'kullback')
time_acc = toc

save('results_train=15_k=2500.mat')