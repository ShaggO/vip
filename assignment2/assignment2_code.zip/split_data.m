function [train_paths,D_train_idx,D_train,test_paths,D_test_idx,D_test] = split_data(n_train,n_test)
    
load('descriptors.mat')

train_paths = paths(:,1:n_train);
train_idx = (D_idx(:,2) <= n_train);
D_train = D(train_idx,:);
D_train_idx = D_idx(train_idx,:);
test_paths = paths(:,n_train+(1:n_test));
test_idx = (D_idx(:,2) > n_train) & (D_idx(:,2) <= n_train+n_test);
D_test = D(test_idx,:);
D_test_idx = D_idx(test_idx,:) - repmat([0 n_train],[sum(test_idx) 1]);