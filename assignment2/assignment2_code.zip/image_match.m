function accuracy = image_match(table_train, table_test, method)

dists = bow_distance(table_train, table_test, method);
[~,sorted_dists] = sort(dists, 'ascend');

matches = 0;
for n = 1:size(table_test,1)
%     total_dists = zeros(101,1);
%     for i = 1:size(table_train,1)
%         cat = table_train{i}.cat;
%         total_dists(cat) = total_dists(cat) + dists(i,n);
%     end
%     [~,best_cat] = min(total_dists);
    
    best_cat = table_train{sorted_dists(1,n)}.cat;
    
    if table_test{n}.cat == best_cat
        matches = matches + 1;
    end
    
    if n == 11 || n == 18
        figure
        set(gcf,'PaperOrientation','landscape');
        set(gcf,'PaperUnits','normalized');
        set(gcf,'PaperPosition', [0 0 1 1]);
        subplot(2,4,1)
        imshow(char(table_test{n}.path))
        title('Test image')
        subplot(2,4,5)
        bar(1:numel(table_test{11}.bow),table_test{n}.bow)
        for i = 1:3
            subplot(2,4,i+1)
            imshow(char(table_train{sorted_dists(i,n)}.path))
            if table_test{n}.cat == table_train{sorted_dists(i,n)}.cat
                title(sprintf('Matched image %d (success)\nd = %.4f',i,dists(sorted_dists(i,n),n)))
            else
                title(sprintf('Matched image %d (fail)\nd = %.4f',i,dists(sorted_dists(i,n),n)))
            end
            subplot(2,4,i+5)
            bar(1:numel(table_train{sorted_dists(i,n)}.bow),table_train{sorted_dists(i,n)}.bow)
        end
        saveas(gcf,['results_' num2str(n) '.pdf'])
    end
    
    %     if (table_test{n}.cat == table_train{sorted_dists(1,n)}.cat) && ...
    %             (table_test{n}.cat ~= best_cat)
    %         figure
    %         set(gcf,'units','normalized','outerposition',[0 0 1 1])
    %         subplot(1,pics+1,1)
    %         imshow(char(table_test{n}.path))
    %         title('first correct but following wrong')
    %         for i = 1:pics
    %             subplot(1,pics+1,i+1)
    %             imshow(char(table_train{sorted_dists(i,n)}.path))
    %             if table_test{n}.cat == table_train{sorted_dists(i,n)}.cat
    %                 title(sprintf('match!\nd = %.2f',dists(sorted_dists(i,n),n)))
    %             else
    %                 title(sprintf('error!\nd = %.2f',dists(sorted_dists(i,n),n)))
    %             end
    %         end
    %         total_dists
    %         best_cat
    %         first_cat = table_train{sorted_dists(1,n)}.cat
    %     end
end

accuracy = matches / size(table_test,1);

end

