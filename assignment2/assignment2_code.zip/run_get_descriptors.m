clc, clear all

run('C:\vlfeat-0.9.17\toolbox\vl_setup.m')

threshold = 10;
n_images = 30;
n_cats = 101;
[cats, paths] = get_data(n_images,n_cats);
[D_idx, D] = get_descriptors(paths,threshold);

save('descriptors.mat')