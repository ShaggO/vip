clc, clear all

run('C:\vlfeat-0.9.17\toolbox\vl_setup.m')

n_train = 5;
n_test = 5;
k_range = 500:500:3000;
nth_descriptor = 10;

[train_paths,D_train_idx,D_train,test_paths,D_test_idx,D_test] = ...
    split_data(n_train,n_test);

for i = 1:numel(k_range)
    k = k_range(i);
    train_idx = 1:nth_descriptor:size(D_train,1);
    
    % k-means clustering
    tic
    [words,~] = vl_ikmeans(D_train(train_idx,:)',k);
    words = words';
    results{i}.time_kmeans = toc;
    
    % get table for each image containing bag of words
    tic
    table_train = get_table(words,train_paths,D_train,D_train_idx);
    table_test = get_table(words,test_paths,D_test,D_test_idx);
    results{i}.time_bow = toc;
    
    % compute image distances and matching accuracy
    tic
    results{i}.acc_euclidean = image_match(table_train, table_test, 'euclidean');
    results{i}.acc_bhattacharyya = image_match(table_train, table_test, 'bhattacharyya');
    results{i}.acc_kullback = image_match(table_train, table_test, 'kullback');
    results{i}.time_acc = toc;
    results{i}
end

save('results_k.mat')

figure
hold on
for i = 1:numel(results)
    plot(k_range(i),results{i}.acc_euclidean,'r.','MarkerSize',20)
    plot(k_range(i),results{i}.acc_bhattacharyya,'k.','MarkerSize',20)
    plot(k_range(i),results{i}.acc_kullback,'b.','MarkerSize',20)
end
xlabel('k')
ylabel('accuracy')
legend('Euclidean','Bhattacharyya','Kullback-Leibler','location','northwest')
hold off
save_figure('results_k.pdf')

for i = 1:numel(results)
    T(i,1) = results{i}.time_kmeans;
    T(i,2) = results{i}.time_bow;
    T(i,3) = results{i}.time_acc;
end
figure
bar(k_range,T,'stacked')
xlabel('k')
ylabel('seconds')
legend('k-means','bags of words','image matching','location','northwest')
save_figure('results_k_time.pdf')