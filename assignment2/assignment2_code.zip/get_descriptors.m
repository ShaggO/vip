function [D_idx, D] = get_descriptors(image_paths,threshold)

D_idx = [];
D = [];

for i = 1:size(image_paths,1)
    for j = 1:size(image_paths,2)
        I = imread(image_paths{i,j});
        if size(I,3) == 3
            I = rgb2gray(I);
        end
        [~,d] = vl_sift(single(I),'EdgeThresh',threshold);
        
        D_idx = [D_idx; ones(size(d,2),1)*i, ones(size(d,2),1)*j];
        D = [D; d'];
    end
end

end

