function [cats, paths] = get_data(n_images, n_cats)

path = '101_ObjectCategories';
cats_mat = ls(path);

cats = cell(n_cats,1);
paths = cell(n_cats,n_images);

for i = 1:n_cats
    cats{i} = strtrim(cats_mat(i+3,:));
    objs_mat = ls([path '/' cats{i}]);
    for j = 1:n_images
        paths{i,j} = [path '/' cats{i} '/' strtrim(objs_mat(j+2,:))];
    end
end

end

