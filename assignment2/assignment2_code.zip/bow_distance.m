function dists = bow_distance(table_train, table_test, method)

dists = zeros(size(table_train,1), size(table_test,1));
for i = 1:size(table_train,1)
    for j = 1:size(table_test,1)
        b1 = table_train{i}.bow;
        b2 = table_test{j}.bow;
        
        if strcmp(method, 'euclidean')
            d = sqrt(sum((b2 - b1).^2));
        elseif strcmp(method, 'bhattacharyya')
            d = 1-sum(sqrt(b1 .* b2));
        elseif strcmp(method, 'kullback')
            d_1 = sum(b1 .* log(b1 ./ (b2 + 10^-6) + 10^-6));
            d_2 = sum(b2 .* log(b2 ./ (b1 + 10^-6) + 10^-6));
            d = d_1/2 + d_2/2;
        end
        
        dists(i,j) = d;
    end
end

end

