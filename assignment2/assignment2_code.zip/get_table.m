function table = get_table(words, paths, D, D_idx)

k = size(words,1);
table = cell(numel(paths),1);
for n = 1:numel(paths)
    [i,j] = ind2sub(size(paths),n);
    c = vl_ikmeanspush(D(D_idx(:,1) == i & D_idx(:,2) == j,:)',words');
    b = hist(c,1:k);
    
    table{n}.path = paths(i,j);
    table{n}.cat = i;
    table{n}.bow = b/sum(b);
end

end

